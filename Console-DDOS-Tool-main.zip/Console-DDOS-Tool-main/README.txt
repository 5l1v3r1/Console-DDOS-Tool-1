This is a basic panel. I just made it for fun cause I was bored ;)
Do not use this for MALICOUS REASONS, this was made for educational purposes.

[+]How To Use[+]
1.You will need your own api. doesn't matter if it's yours or you bought someone elses.
2.Make sure you have all of the packages installed required to use this program.
3.Idc if you use this to sell jsut make sure to put obf on it and give me some creds in the program thanks.

[+] Questions [+]
If you have any questions on how to use or set this up then you shouldn't be using this. If you can't figure out what to do even after I told you then please jsut move on this isn't for you.

[+] Previews [+] 
https://imgur.com/a/ozJRWhH

Enjoy 
